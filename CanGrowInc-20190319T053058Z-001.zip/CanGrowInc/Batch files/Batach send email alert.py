import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import psycopg2 as pg2
from datetime import timedelta, datetime, date

######################################################
#list of function():

def getDbConnection(): #Get Database connection
    try:
        connection =pg2.connect(user='FAT', #DB auth
                             password='Frontier',
                             host='',
                             port='5432',
                             database='Farm') 
        print ("DB is connected succefully")
        return connection
    except(Exception, pg2.DatabaseError) as error:
        print("Failed to connect to database")

def closeDbConnection(connection):
    #Close Database connection
    try:
        connection.close()
        print("connection of DB had close succefully")
    except(Exception, pg2.DatabaseError) as error:
        print("Failed to close database connection")        

def RetiveDBdata():
    try:
        connection = getDbConnection()
        cursor = connection.cursor()
        
        # retive value form tank tables
        tank = 'SELECT * FROM "CGI_tank_system" ORDER BY "datetime" DESC '
        cursor.execute(tank)
        tank_system = cursor.fetchone()

        # retive value form room tables
        room = 'SELECT * FROM "CGI_ambient" ORDER BY "datetime" DESC '
        cursor.execute(room)
        room_system = cursor.fetchone()

        # retive value form limit tables
        limit = 'SELECT * FROM "CGI_limit"'
        cursor.execute(limit)
        limit_system = cursor.fetchone()

        # this use to better undtifilying the values
        

            #for tank 
        ph = tank_system[1],
        ec = tank_system[2],
        WaterFlowInlet = tank_system[3],
        WaterFlowOutlet = tank_system[4],
        WaterLevel = tank_system[5],
        WaterTemp = tank_system[6],

            #for room 
        RoomTemp = room_system[1],
        CO2 = room_system[2],
        O2 = room_system[3],
        humdity = room_system[4],

            #for limits
        Max_ph = limit_system[1],
        Mini_ph = limit_system[2],
        Max_EC = limit_system[3],
        Mini_EC = limit_system[4],
        Max_CO2 = limit_system[5],
        Mini_CO2 = limit_system[6],
        Max_FlowOut = limit_system[7],
        Mini_FlowOut = limit_system[8],
        Max_FlowIn = limit_system[9],
        Mini_FlowIn = limit_system[10],
        Max_Humdity = limit_system[11],
        Mini_Humdity = limit_system[12],
        Max_TankLevel = limit_system[13],
        Mini_TankLevel = limit_system[14],
        Max_RoomTemp = limit_system[15],
        Mini_RoomTemp = limit_system[16],
        Max_WaterTemp = limit_system[17],            
        Mini_WaterTemp = limit_system[18],
    

        #  value {= more} max limit or value {= less} mini limit (ph)
        if ph >= Max_ph or ph <= Mini_ph:
            message = '''Warning ph value had hit over limit or under limit.
                        This is auto genrated mail please do not reply
                        Current value ph is: ''' 
            smtp_email(message,ph)

        #value {= more} max limit or value {= less} mini limit (EC)
        if ec >= Max_EC or ec <= Mini_EC:
            message = '''Warning ec value had hit over limit or under limit.
                        This is auto genrated mail please do not reply
                        Current value ec is: ''' 
            smtp_email(message,ec)

        #value {= more} max limit or value {= less} mini limit (WaterINtlet)
        if WaterFlowInlet >= Max_FlowIn or WaterFlowInlet <= Mini_FlowIn:
            message = '''Warning Water flowing IN of tank; values had hit over limit or under limit.
                        Please check this may cause equimpnet damgage of flooding.
                        This is auto genrated mail please do not reply
                        Current value is: ''' 
            #smtp_email(message,WaterFlowInlet)

        #value {= more} max limit or value {= less} mini limit (WaterOUTlet)
        if WaterFlowOutlet >= Max_FlowOut or WaterFlowOutlet <= Mini_FlowOut :
            message = '''Warning Water flowing out of tank; values had hit over limit or under limit.
                        Please check this may cause equimpnet damgage of flooding.
                        This is auto genrated mail please do not reply
                        Current value is: ''' 
            smtp_email(message,WaterFlowOutlet)

        #value {= more} max limit or value {= less} mini limit (CO2)
        if CO2 >= Max_CO2 or CO2 <= Mini_CO2:
            message = '''Warning CO2 value had hit over limit or under limit.
                        This is auto genrated mail please do not reply
                        Current value CO2 is: '''
            smtp_email(message,CO2)

                #value {= more} max limit or value {= less} mini limit (Humdity)
        if humdity >= Max_Humdity or humdity <= Mini_Humdity:
            message = '''Warning Humdity value had hit over limit or under limit.
                        This is auto genrated mail please do not reply
                        Current value Humdity is: '''
            smtp_email(message,humdity)

        #  value {= more} max limit or value {= less} mini limit (RoomTemp)
        if RoomTemp >= Max_RoomTemp or RoomTemp <= Mini_RoomTemp:
            message = '''Warning Room Temptures, value had hit over limit or under limit.
                        This is auto genrated mail please do not reply
                        Current value Room Temptures is: '''    
            smtp_email(message,RoomTemp)

        # value {= more} max limit or value {= less} mini limit (WaterTemp)
        if WaterTemp >= Max_WaterTemp or  WaterTemp <= Mini_WaterTemp:
            message = '''Warning Water Temptures, value had hit over limit or under limit. 
                        This is auto genrated mail please do not reply
                        Current value Water Temptures is: '''
            smtp_email(message,WaterTemp)

        #value {= more} max limit or value {= less} mini limit (WaterLevel)
        if WaterLevel >= Max_TankLevel or WaterLevel <= Mini_TankLevel:
            message = '''Warning  Water Level had hit over limit or under limit.
                        This is auto genrated mail please do not reply
                        Current value  is: '''
            smtp_email(message,WaterLevel)

    except(Exception, pg2.DatabaseError) as error:
        print("Failed to retive database data")
        print(error)
    
    finally:
            closeDbConnection(connection)



def smtp_email(message,values):
    #print #("start email config")#
    port = 587
    smtp_server = "smtp.gmail.com"
    sender_email = "weiwei.tpgig1718@gmail.com"  # Enter your address
    receiver_email = "weiwei.tpgig1718@gmail.com"  # Enter receiver address
    password = "shuwei127"
    subject = 'ALERT '
    message = message + str(values)

    msg = MIMEMultipart() # libery to clarlyfity 
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

        # Create a secure SSL context
    context = ssl.create_default_context()
    with smtplib.SMTP(smtp_server, port) as server:
        server.ehlo()  # Can be omitted
        server.starttls(context=context) # secure the content
        server.ehlo()  # Can be omitted
        server.login(sender_email, password) # login in email
        text = msg.as_string() # load message into varables
        server.ehlo()  # Can be omitted
        server.sendmail(sender_email, receiver_email, text, )
        print ("email send")
        server.quit()
        print ("log out email")
    # TODO: Send email here)

#########################
#run codes
RetiveDBdata()
