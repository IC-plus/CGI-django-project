#import liberys 
import psycopg2 as pg2
from datetime import timedelta, datetime, date

############################################
# Function codes
def getDbConnection():
    #Get Database connection
    try:
        connection =pg2.connect(user='FAT',
                             password='Frontier',
                             host='',
                             port='5432',
                             database='Farm') 
        print ("DB is connected succefully")
        return connection
    except(Exception, pg2.DatabaseError) as error:
        print("Failed to connect to database")

def closeDbConnection(connection):
    #Close Database connection
    try:
        connection.close()
        print("connection of DB had close succefully")
    except(Exception, pg2.DatabaseError) as error:
        print("Failed to close database connection")

def DeleteDBdata():
    try:
        
        connection = getDbConnection()
        cursor = connection.cursor()
        datastamp = datetime.now().year - 2
        
        query ='"DELETE FROM "CGI_tank_system" WHERE datetime < now()- interval "2 year"'
        
        cursor.execute(query,)
        connection.commit()
        row_count = cursor.rowcount
        print(row_count, "Record Deleted")
        
    except(Exception, pg2.DatabaseError) as error:
        print("Failed to execute database delete program")
        print(error)

    finally:
            closeDbConnection(connection)
    
def DisplayDBdata():
    try:
        connection = getDbConnection()
        cursor = connection.cursor()
        tank_query = 'SELECT * FROM "CGI_tank_system" ORDER BY "datetime" DESC '
        ambient_query = 'SELECT * FROM "CGI_ambient" ORDER BY "datetime" DESC'
        cursor.execute(tank_query,)
        records = cursor.fetchall()

        #for row in records:
        print("id: = ", records[0])
        
    except(Exception, pg2.DatabaseError) as error:
        print("Failed to execute database program")
        print(error)
    

    finally:
            closeDbConnection(connection)


#############################################################
#code to be excuted
#DeleteDBdata()
DisplayDBdata() #for testing only

#end of code thats excute
