from django.contrib import admin
from CGI.models import tank_system,ambient, Limit



# Change admin site title
admin.site.site_header = ("Farm Administration")
admin.site.site_title = ("Farm Admin")

#database show and unshow
admin.site.register(tank_system)
admin.site.register(ambient)
admin.site.register(Limit)

