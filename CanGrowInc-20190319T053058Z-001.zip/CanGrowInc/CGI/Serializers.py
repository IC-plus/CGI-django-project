from django.contrib.auth.models import User, Group
from CGI.models import tank_system, ambient
from rest_framework import serializers

class tankSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = tank_system
        fields = ('PH', 'EC', 'Winlet', 'Woutlet', 'WaterLevel', 'TempWater', 'datetime')

class RoomSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = ambient
        fields = ('TempRoom', 'CO2', 'Humdity', 'O2', 'datetime')