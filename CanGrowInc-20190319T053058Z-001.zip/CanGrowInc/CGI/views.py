from django.shortcuts import render, get_object_or_404
from CGI.models import tank_system, ambient, Limit
from CGI.basicfun import selectDates, weekSelect
import logging
logger = logging.getLogger(__name__)

from django.contrib.auth.models import User
from rest_framework import viewsets
from CGI.Serializers import tankSerializer, RoomSerializer

from django.template import RequestContext

def index(request):
    tank = tank_system.objects.latest('datetime')
    room = ambient.objects.latest('datetime')
    limit, created = (Limit.objects.get_or_create())
    return render(request, 'CGI/Pages/DashBoard.html', {'tank':tank,'room':room, 'limit':limit})


def Lquid(request):
    query = request.GET.get('dateRange')

    if query == 'Select-date':
        partculer = request.GET.get('partculer')
        data = tank_system.objects.all().filter(datetime__icontains=partculer).order_by('datetime')

    elif query == "Select-range" or query == "This-Week" or query == "Previous-Week":
        if query == 'select-range':
            start = request.GET.get('start')
            end = request.GET.get('end')

        else:
            start = request.GET.get('start')
            end = request.GET.get('end')
            start, end = weekSelect(query)
        data = tank_system.objects.all().filter(datetime__gte=start, datetime__lte=end).order_by('datetime')

    else:
        fill = selectDates(query)
        data = tank_system.objects.all().filter(datetime__contains=fill).order_by('datetime')
    return render(request, 'CGI/Pages/WaterChart.html', {'tank': data})

def Ambient(request):
    query = request.GET.get('dateRange')

    if query == 'Select-date':
        partculer = request.GET.get('partculer')
        data = ambient.objects.all().filter(datetime__icontains=partculer).order_by('datetime')

    elif query == "Select-range" or query == "This-Week" or query == "Previous-Week":
        if query == 'select-range':
            start = request.GET.get('start')
            end = request.GET.get('end')

        else:
            start = request.GET.get('start')
            end = request.GET.get('end')
            start, end = weekSelect(query)
        data = ambient.objects.all().filter(datetime__gte=start, datetime__lte=end).order_by('datetime')

    else:
        fill = selectDates(query)
        data = ambient.objects.all().filter(datetime__contains=fill).order_by('datetime')
    return render(request, 'CGI/Pages/RoomChart.html', {'room': data})


def Test(request):
    query = request.GET.get('dateRange')
    limit = Limit.objects.all()
    print(query)
    return render(request, 'CGI/Pages/Testpage.html', {'limit':limit})

class TankViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = tank_system.objects.all()
    serializer_class = tankSerializer

class RoomViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = ambient.objects.all()
    serializer_class = RoomSerializer
