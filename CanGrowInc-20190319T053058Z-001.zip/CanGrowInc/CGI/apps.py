from django.apps import AppConfig


class CgiConfig(AppConfig):
    name = 'CGI'
