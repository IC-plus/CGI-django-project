from django.utils import timezone
from datetime import timedelta, datetime, date
from dateutil.relativedelta import relativedelta

def selectDates(query):

    dataset =  datetime.now().date()
                    # Days filter #
    if query == 'Today' or  query== 'None':
        dataset = datetime.now().date() # call today datas
    if query == 'Yesteday':
        dataset = datetime.now().date() - timedelta(1)
                        # Days filter #


                        # Months filter #
    if query == 'This-Months':
        dataset = datetime.now().strftime("%Y-%m")# take this months


    if query == 'Previous-Months':
        today = date.today()  # 2019-01-03
        dataset =(today - relativedelta(months=1)).strftime('%Y-%m')
                # end of Months filter #

                        # Year filter #
    if query == 'This-Year':
        dataset = datetime.now().year

    if query == 'Last-Year':
        dataset = datetime.now().year - 1
                        # end of Year filter #
    return dataset

def weekSelect (query):
                        # Weeks Filter #
        some_day_last_week = timezone.now().date() - timedelta(days=7)
        monday_of_last_week = some_day_last_week - timedelta(days=(some_day_last_week.isocalendar()[2] - 1))
        monday_of_this_week = monday_of_last_week + timedelta(days=7)
        monday_of_next_week = monday_of_this_week + timedelta(days=7)

        if query == 'This-Week':
            # this week data
            return monday_of_this_week, monday_of_next_week

        if query == 'Previous-Week':
            #last week data
            return monday_of_last_week, monday_of_this_week
                #Weeks Filter #
