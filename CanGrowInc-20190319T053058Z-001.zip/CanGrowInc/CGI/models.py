from django.db import models
from django.utils import timezone

class tank_system(models.Model):
    PH = models.DecimalField(default=7.5,max_digits=3, decimal_places=1)
    EC = models.DecimalField(default=13.3,max_digits=3, decimal_places=1)
    Winlet = models.DecimalField(default=20.1, max_digits=3, decimal_places=1)
    Woutlet = models.DecimalField(default=20.3,max_digits=3, decimal_places=1)
    WaterLevel = models.IntegerField(default=500)
    TempWater = models.IntegerField(default=25)
    tanks = models.IntegerField(default=1)
    datetime = models.DateTimeField(default=timezone.now())




class ambient (models.Model):
    TempRoom = models.IntegerField(default=25)
    CO2 = models.DecimalField(default=20.0, max_digits=3, decimal_places=1)
    O2 = models.DecimalField(default=20.0,max_digits=3, decimal_places=1)
    Humdity = models.IntegerField(default=25)
    Room = models.IntegerField(default=1)
    datetime = models.DateTimeField(default=timezone.now())


class Limit (models.Model):
    #Tolerance =
    Max_pH = models.DecimalField(default=8,max_digits=3, decimal_places=1)
    Mini_pH = models.DecimalField(default=5.9,max_digits=3, decimal_places=1)

    Max_EC = models.DecimalField(default=3.0,max_digits=3, decimal_places=1)
    Mini_EC = models.DecimalField(default=1.8,max_digits=3, decimal_places=1)

    Max_CO2 = models.DecimalField(default=20,max_digits=3, decimal_places=1)
    Mini_CO2 = models.DecimalField(default=10,max_digits=3, decimal_places=1)

    Max_FlowOut = models.DecimalField(default=100,max_digits=4, decimal_places=1)
    Mini_FlowOut = models.DecimalField(default=20,max_digits=4, decimal_places=1)

    Max_FlowIn = models.DecimalField(default=100,max_digits=4, decimal_places=1)
    Mini_FlowIn = models.DecimalField(default=20,max_digits=4, decimal_places=1)

    Max_Humdity = models.DecimalField(default=65,max_digits=3, decimal_places=1)
    Mini_Humdity = models.DecimalField(default=54,max_digits=3, decimal_places=1)

    Max_TankLevel = models.IntegerField(default=1000)
    Mini_TankLevel = models.IntegerField(default=100)

    Max_RoomTemp = models.DecimalField(default=28,max_digits=3, decimal_places=1)
    Mini_RoomTemp = models.DecimalField(default=24,max_digits=3, decimal_places=1)

    Max_WaterTemp = models.DecimalField(default=21.5,max_digits=3, decimal_places=1)
    Mini_WaterTemp = models.DecimalField(default=18.5,max_digits=3, decimal_places=1)

    def __int__(self):
        return self.id