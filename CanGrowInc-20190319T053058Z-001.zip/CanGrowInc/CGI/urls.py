from django.urls import path, include
from . import views #function views
from django.contrib.auth.decorators import login_required, permission_required


from rest_framework import routers
router = routers.DefaultRouter()
router.register(r'tank', views.TankViewSet)
router.register(r'room', views.RoomViewSet)
# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.

urlpatterns = [
    path(r'',login_required(views.index), name='index'),
    path (r'test/',views.Test),
    path(r'^Water-data-chart/',login_required(views.Lquid), name='tank'),
    path(r'^Ambient-data-chart/',login_required(views.Ambient), name='room'),
    path(r'Rest-api/', include(router.urls))
    ]